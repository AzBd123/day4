import { createContext  } from "react"
  

export const HobbiesContext = createContext();

